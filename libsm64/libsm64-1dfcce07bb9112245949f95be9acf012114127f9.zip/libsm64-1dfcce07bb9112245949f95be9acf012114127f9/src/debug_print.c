#include "debug_print.h"

SM64DebugPrintFunctionPtr g_debug_print_func = NULL;