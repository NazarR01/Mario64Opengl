#ifndef GUMTXF2L_H
#define GUMTXF2L_H

#include "../include/PR/gbi.h"

extern void guMtxF2L(float mf[4][4], Mtx *m);
extern void guMtxL2F(float mf[4][4], Mtx *m);

#endif//GUMTXF2L_H