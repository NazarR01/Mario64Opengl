#ifndef MARIO_ACTIONS_SUBMERGED_H
#define MARIO_ACTIONS_SUBMERGED_H

#include "../include/PR/ultratypes.h"

#include "../include/types.h"

s32 mario_execute_submerged_action(struct MarioState *m);

#endif // MARIO_ACTIONS_SUBMERGED_H
