#ifndef MARIO_ACTIONS_AUTOMATIC_H
#define MARIO_ACTIONS_AUTOMATIC_H

#include "../include/PR/ultratypes.h"

#include "../include/types.h"

s32 mario_execute_automatic_action(struct MarioState *m);

#endif // MARIO_ACTIONS_AUTOMATIC_H
