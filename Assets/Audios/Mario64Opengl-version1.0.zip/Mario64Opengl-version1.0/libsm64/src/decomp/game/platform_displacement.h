#ifndef PLATFORM_DISPLACEMENT_H
#define PLATFORM_DISPLACEMENT_H

#include "../include/PR/ultratypes.h"
#include "../include/types.h"

void update_mario_platform(void);
void apply_mario_platform_displacement(void);

#endif // PLATFORM_DISPLACEMENT_H
