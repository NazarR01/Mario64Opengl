#pragma once

#include "../include/types.h"
#include "../mario/model.inc.h"

extern Gfx *geo_move_mario_part_from_parent(s32 run, UNUSED struct GraphNode *node, Mat4 mtx);