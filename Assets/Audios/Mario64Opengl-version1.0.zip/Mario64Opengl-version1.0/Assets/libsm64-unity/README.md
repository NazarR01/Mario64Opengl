# libsm64-unity

Unity engine demo client of libsm64. This repo provides a Unity package which can be imported from the
package manager. For some example scenes on how to use it, or to just get started hacking around with
it directly, check out the [libsm64-unity-dev](https://github.com/libsm64/libsm64-unity-dev) repo.
