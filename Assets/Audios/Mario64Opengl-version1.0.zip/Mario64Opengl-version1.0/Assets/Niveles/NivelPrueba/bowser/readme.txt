This model was ripped by Donowa using Fast64 for The Models Resource. 
No credit is needed.
The bowser_edited_newrest file contains a modified rig and rest pose that should be easier to t-pose, as well as removing redundant bones.
All the other DAE files contain one animation each, and also have the original game's (pretty terrible) rig.
All duplicated files were like that in the original game.